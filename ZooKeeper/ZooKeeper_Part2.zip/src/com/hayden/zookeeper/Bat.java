package com.hayden.zookeeper;

public class Bat extends Mammal {

	public Bat() {
		super.setEnergyLevel(300);
	}
	
	public void fly() {
		System.out.println("WHOOSH");
		this.setEnergyLevel(this.getEnergyLevel()-50);
	}
	
	public void eatHumans() {
		System.out.println("The sound of screaming humans as they are devoured echoes across the plains.");
		this.setEnergyLevel(this.getEnergyLevel()+25);
	}
	
	public void attackTown() {
		System.out.println("Fires rage and crackle across the town.");
		this.setEnergyLevel(this.getEnergyLevel()-100);
	}

}
