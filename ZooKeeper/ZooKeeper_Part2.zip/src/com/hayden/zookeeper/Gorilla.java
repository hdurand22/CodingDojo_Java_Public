package com.hayden.zookeeper;

public class Gorilla extends Mammal {

	public Gorilla() {
		
	}
	
	public void throwThings() {
		this.setEnergyLevel(this.getEnergyLevel()-5);
		System.out.println("Things are flying through the air.");
	}
	
	public void eatBananas() {
		this.setEnergyLevel(this.getEnergyLevel()+10);
		System.out.println("The gorilla is eating bananas.");
	}
	
	public void climb() {
		this.setEnergyLevel(this.getEnergyLevel()-10);
		System.out.println("The gorilla is climbing a tree.");
	}

}
