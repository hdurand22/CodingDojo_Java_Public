package com.hayden.zookeeper;

public class TestBat {

	public static void main(String[] args) {
		Bat b1 = new Bat();
		
		b1.attackTown();
		b1.displayEnergy();
		b1.attackTown();
		b1.displayEnergy();
		b1.attackTown();
		b1.displayEnergy();
		b1.eatHumans();
		b1.displayEnergy();
		b1.eatHumans();
		b1.displayEnergy();
		b1.fly();
		b1.displayEnergy();
		b1.fly();
		b1.displayEnergy();

	}

}
