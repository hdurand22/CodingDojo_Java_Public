import java.util.HashMap;
import java.util.Set;

public class Hashmatique {
    public static void main(String[] args) {
        HashMap<String, String> trackMap = new HashMap<String, String>();
        trackMap.put("One For The Road", "I met her at a truck stop in September...");
        trackMap.put("Captain Tripps", "Dirty people lying dying in the stadium...");
        trackMap.put("Comin' Up", "Smoke is rising on top of the hill...");
        trackMap.put("For My Nan", "Geriatrics have all the fun...");

        String track = trackMap.get("Captain Tripps");
        System.out.println(track);

        Set<String> allTracks = trackMap.keySet();
        for (String key : allTracks) {
            System.out.println(key+": "+trackMap.get(key));
        }

    }
}