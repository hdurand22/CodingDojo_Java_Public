package com.hayden.bankaccount;
import java.util.Random;

public class BankAccount {
	private double checkingBalance;
	private double savingsBalance;
	private static int numOfAccounts = 0;
	private static double totalBalance = 0;
	private String accountNumber;
	
	// Constructors 
	public BankAccount() {
		numOfAccounts++;
		accountNumber = this.generateAccountNumber();
	}
	
	// Class methods
	public void deposit(String account, double amount) {
		account = account.toUpperCase();
//		System.out.println("account: "+ account);
		
		if (account.equals("CHECKING")) {
			this.setCheckingBalance(this.getCheckingBalance()+amount);
			totalBalance += amount;
		}
		else if (account.equals("SAVINGS")) {
			this.setSavingsBalance(this.getSavingsBalance()+amount);
			totalBalance += amount;
		}
		else {
			System.out.println("Invalid account type");
		}
	}
	
	public void withdraw(String account, double amount) {
		account = account.toUpperCase();
		
		if (account.equals("CHECKING")) {
			double currentBalance = this.getCheckingBalance();
			if (currentBalance >= amount) {
				this.setCheckingBalance(this.getCheckingBalance()-amount);
				totalBalance -= amount;
			}
			else {
				System.out.println("Insufficient funds in checking account");
			}
		}
		else if (account.equals("SAVINGS")) {
			double currentBalance = this.getSavingsBalance();
			if (currentBalance >= amount) {
				this.setSavingsBalance(this.getSavingsBalance()+amount);
				totalBalance += amount;
			}
			else {
				System.out.println("Insufficient funds in savings account");
			}
		}
		else {
			System.out.println("Invalid account type");
		}
	}
	
	private String generateAccountNumber() {
		Random rand = new Random();
		String accountNumber = "";
		
		for (int i=0; i<10; i++) {
			accountNumber += String.valueOf(rand.nextInt(10));
		}
		
		return accountNumber;
	}
	
	// Getters and setters
	public double getCheckingBalance() {
		return checkingBalance;
	}

	private void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}

	public double getSavingsBalance() {
		return savingsBalance;
	}

	private void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}

	public static int getNumOfAccounts() {
		return numOfAccounts;
	}

	public static double getTotalBalance() {
		return totalBalance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

}
