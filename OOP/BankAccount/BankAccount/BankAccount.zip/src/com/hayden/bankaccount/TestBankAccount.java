package com.hayden.bankaccount;

public class TestBankAccount {

	public static void main(String[] args) {
		BankAccount acct1 = new BankAccount();
		
		System.out.println(acct1.getAccountNumber());
		System.out.println(BankAccount.getTotalBalance());
		System.out.println(BankAccount.getNumOfAccounts());
		acct1.deposit("Checking", 100.0);
		acct1.deposit("Savings", 1000.0);
		System.out.println(BankAccount.getTotalBalance());
		acct1.withdraw("checking", 200.0);
		acct1.withdraw("checking", 45.6);
		acct1.withdraw("savings", 400);
		System.out.println(BankAccount.getTotalBalance());
		
		BankAccount acct2 = new BankAccount();
		System.out.println(BankAccount.getNumOfAccounts());
		System.out.println(acct2.getAccountNumber());


	}

}
