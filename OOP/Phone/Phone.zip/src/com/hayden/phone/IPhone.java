package com.hayden.phone;

public class IPhone extends Phone implements Ringable {
	
	public IPhone(String versionNumber, int batteryPercentage, String carrier, String ringTone) {
		super(versionNumber, batteryPercentage, carrier, ringTone);
	}

	@Override
	public String ring() {
		return String.format("iPhone %s says %s", this.getVersionNumber(), this.getRingTone());
	}

	@Override
	public String unlock() {
		return "Unlocking iPhone via facial recognition...";
	}

	@Override
	public void displayInfo() {
		System.out.println("iPhone version: "+this.getVersionNumber());
		System.out.println("iPhone carrier: " +this.getCarrier());
		System.out.println("iPhone battery percentage: "+String.valueOf(this.getBatteryPercentage()));
		
	}

}
