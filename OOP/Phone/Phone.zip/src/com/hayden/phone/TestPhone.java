package com.hayden.phone;

public class TestPhone {

	public static void main(String[] args) {
		Galaxy g1 = new Galaxy("S9", 83, "Verizon", "Ring, ring, ring");
		IPhone i1 = new IPhone("X", 66, "T-Mobile", "Xylophone noises");
		
		g1.displayInfo();
		System.out.println(g1.ring());
		System.out.println(g1.unlock());
		
		i1.displayInfo();
		System.out.println(i1.ring());
		System.out.println(i1.unlock());

	}

}
