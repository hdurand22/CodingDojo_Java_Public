package com.hayden.phone;

public class Galaxy extends Phone implements Ringable {
	
	public Galaxy(String versionNumber, int batteryPercentage, String carrier, String ringTone) {
		super(versionNumber, batteryPercentage, carrier, ringTone);
	}

	@Override
	public String ring() {
		return String.format("Galaxy %s says %s", this.getVersionNumber(), this.getRingTone());
	}

	@Override
	public String unlock() {
		return "Unlocking Galaxy via fingerprint...";
	}

	@Override
	public void displayInfo() {
		System.out.println("Galaxy version: "+this.getVersionNumber());
		System.out.println("Galaxy carrier: " +this.getCarrier());
		System.out.println("Galaxy battery percentage: "+String.valueOf(this.getBatteryPercentage()));
		
	}

}