package com.hayden.objectmaster;

public class Samurai extends Human {
	private static int totalSamurai = 0;
	
	public Samurai() {
		super.setHealth(200);
		totalSamurai++;
	}
	
	public void deathBlow(Human target) {
		target.setHealth(0);
		this.setHealth(this.getHealth()/2);
	}
	
	public void meditate() {
		this.setHealth(this.getHealth()+(this.getHealth()/2));
	}
	
	public int howMany() {
		return totalSamurai;
	}

}
