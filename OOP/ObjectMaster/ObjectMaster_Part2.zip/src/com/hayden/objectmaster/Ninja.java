package com.hayden.objectmaster;

public class Ninja extends Human {

	public Ninja() {
		super.setStealth(10);
	}
	
	public void steal(Human target) {
		int stolenHealth = target.getHealth() - this.getStealth();
		// Take health from target and set target's health
		target.setHealth(stolenHealth);
		this.setHealth(this.getHealth()+this.getStealth());
	}
	
	public void runAway() {
		super.setHealth(this.getHealth()-10);
	}

}
