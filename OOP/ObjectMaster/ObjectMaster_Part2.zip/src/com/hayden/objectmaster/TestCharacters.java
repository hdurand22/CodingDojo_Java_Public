package com.hayden.objectmaster;

public class TestCharacters {

	public static void main(String[] args) {
		Wizard w1 = new Wizard();
		Ninja n1 = new Ninja();
		Samurai s1 = new Samurai();
		
		// Constructor tests
		System.out.println("Wizard health: "+w1.getHealth());
		System.out.println("Wizard int: "+w1.getIntelligence());
		System.out.println("Ninja stealth: "+n1.getStealth());
		System.out.println("Samurai health: "+ s1.getHealth());
		
		// Wizard method tests
		w1.heal(n1);
		System.out.println("Ninja health: "+n1.getHealth());
		w1.fireball(s1);
		System.out.println("Samurai health: "+s1.getHealth());
		
		// Ninja method tests
		n1.steal(s1);
		System.out.println("Ninja health after steal: "+n1.getHealth());
		System.out.println("Samurai health after steal: "+s1.getHealth());
		n1.runAway();
		System.out.println("Ninja health after running away: "+n1.getHealth());
		
		// Samurai method tests
		s1.deathBlow(w1);
		System.out.println("Wizard health: "+w1.getHealth());
		System.out.println("Samurai health after death blow: "+s1.getHealth());
		s1.meditate();
		System.out.println("Samurai health after meditate: "+s1.getHealth());
		System.out.println(s1.howMany());

	}

}
