package com.hayden.objectmaster;

public class HumanTest {

	public static void main(String[] args) {
		Human h1 = new Human();
		Human h2 = new Human();
		
		System.out.println(h1.getHealth());
		System.out.println(h1.getStrength());
		System.out.println(h1.getStealth());
		System.out.println(h1.getIntelligence());
		h1.setStrength(5);
		h1.attack(h2);
		System.out.println(h2.getHealth());

	}

}
