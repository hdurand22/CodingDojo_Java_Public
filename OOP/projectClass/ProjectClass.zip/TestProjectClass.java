public class TestProjectClass {
    public static void main(String[] args) {
        Project p1 = new Project();
        Project p2 = new Project("Secret Project");
        Project p3 = new Project("Next Project", "This is the next project we'll be working on.");
        Project p4 = new Project();
        Portfolio portfolio1 = new Portfolio();

        // Test basic project functionality
        // System.out.println(p1);
        p1.setName("1st Project");
        p1.setDescription("This is the first project.");
        // System.out.println(p1.getElevatorPitch());
        // System.out.println(p2.getName());
        p2.setDescription("This project is a secret.");
        // System.out.println(p2.getElevatorPitch());
        // System.out.println(p3.getDescription());
        p3.setName("New Project");
        // System.out.println(p3.getElevatorPitch());
        p1.setInitialCost(25000);
        p2.setInitialCost(10000.50);
        p3.setInitialCost(50000.00);

        // Test portfolio functionality
        // System.out.println(portfolio1);
        portfolio1.addProject(p1);
        portfolio1.addProject(p2);
        portfolio1.addProject(p3);
        portfolio1.showPortfolio();
        System.out.println(portfolio1.addProject(p1));
        System.out.println(portfolio1.getProject(p4));

    }
}