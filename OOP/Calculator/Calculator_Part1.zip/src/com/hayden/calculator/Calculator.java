package com.hayden.calculator;

public class Calculator implements java.io.Serializable {
	private double operandOne;
	private double operandTwo;
	private String operator;
	private double results;
	
	public Calculator() {
		
	}
	
	public double performOperation(double d, double e, String operator) {
		// Set all the private variables to the arguments coming in
		this.setOperandOne(d);
		this.setOperandTwo(e);
		this.setOperator(operator);
		
		// Check operator type
		if (operator.equals("+")) {
			this.setResults(d + e);
		}
		else if (operator.equals("-")) {
			this.setResults(d - e);
		}
		else if (operator.equals("*")) {
			this.setResults(d * e);
		}
		else if (operator.equals("/")) {
			this.setResults(d / e);
		}
		else {
			System.out.println("Invalid operator");
			return -1;
		}
		
		return this.getResults();
		
	}

	public double getOperandOne() {
		return operandOne;
	}

	public void setOperandOne(double operandOne) {
		this.operandOne = operandOne;
	}

	public double getOperandTwo() {
		return operandTwo;
	}

	public void setOperandTwo(double operandTwo) {
		this.operandTwo = operandTwo;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public double getResults() {
		return results;
	}

	public void setResults(double results) {
		this.results = results;
	}
}
