package com.hayden.calculator;

public class TestCalculator {

	public static void main(String[] args) {
		Calculator calc1 = new Calculator();
		
		System.out.println(calc1.performOperation(10.5, 5.2, "+"));
		System.out.println(calc1.performOperation(22, 11, "/"));
		System.out.println(calc1.performOperation(3, 3, "*"));
		System.out.println(calc1.performOperation(2, 1, "-"));
		System.out.println(calc1.performOperation(2, 3, "&"));

	}

}
