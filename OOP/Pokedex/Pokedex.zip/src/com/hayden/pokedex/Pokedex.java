package com.hayden.pokedex;
import java.util.ArrayList;

public class Pokedex extends AbstractPokemon {
	private ArrayList<Pokemon> myPokemon = new ArrayList<Pokemon>();
	
	public Pokedex() {

	}

	public void listPokemon() {
		for (int i=0; i<this.myPokemon.size(); i++) {
			System.out.println(this.myPokemon.get(i).getName());
		}

	}

	public void addPokemon(Pokemon pokemon) {
		this.myPokemon.add(pokemon);
	}

}
