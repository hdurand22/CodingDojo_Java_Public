package com.hayden.pokedex;

public abstract class AbstractPokemon implements PokemonInterface {

	public Pokemon createPokemon(String name, int health, String type) {
		Pokemon pokemon = new Pokemon(name, health, type);
		return pokemon;
	}

	public String pokemonInfo(Pokemon pokemon) {
		String name = pokemon.getName();
		String health = String.valueOf(pokemon.getHealth());
		String type = pokemon.getType();
		
		return String.format("Name: %s, Health: %s, Type: %s", name, health, type);
	}

}
