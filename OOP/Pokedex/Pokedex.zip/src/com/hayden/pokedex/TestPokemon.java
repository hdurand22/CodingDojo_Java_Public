package com.hayden.pokedex;

public class TestPokemon {

	public static void main(String[] args) {
		Pokemon p1 = new Pokemon("Bulbasaur", 52, "Water");
		System.out.println(p1.pokemonInfo(p1)); // Why do I have to pass the object itself back in
		Pokedex dex1 = new Pokedex();
		dex1.addPokemon(p1);
		dex1.listPokemon();
		System.out.println(Pokemon.getCount());
		
		Pokemon p2 = new Pokemon("Charmander", 48, "Fire");
		Pokemon p3 = new Pokemon("Squirtle", 55, "Water");
		dex1.addPokemon(p2);
		dex1.addPokemon(p3);
		dex1.listPokemon();
		System.out.println(Pokemon.getCount());
		

	}

}
